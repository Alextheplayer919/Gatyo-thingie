import os, re, json
root = "/home/claude/x/apk"
c8  = re.compile(rb"gatyo|(?<![A-Za-z])gato", re.I)
c16 = re.compile(rb"g\x00a\x00t\x00y\x00o\x00|(?<![A-Za-z]\x00)g\x00a\x00t\x00o\x00", re.I)
def ctx8(d,s,e):
    a=s
    while a>0 and s-a<60 and 32<=d[a-1]<127: a-=1
    b=e
    while b<len(d) and b-e<60 and 32<=d[b]<127: b+=1
    return d[a:b].decode("latin1")
def ctx16(d,s,e):
    a=s
    while a>=2 and s-a<120 and 32<=d[a-2]<127 and d[a-1]==0: a-=2
    b=e
    while b+1<len(d) and b-e<120 and 32<=d[b]<127 and d[b+1]==0: b+=2
    return d[a:b].decode("utf-16le","replace")
out={}; n=0
for dp,dn,fn in os.walk(root):
    for f in fn:
        p=os.path.join(dp,f); d=open(p,"rb").read(); n+=1
        res=[]
        for m in c8.finditer(d):  res.append(("ascii",m.start(),ctx8(d,m.start(),m.end())))
        for m in c16.finditer(d): res.append(("utf16",m.start(),ctx16(d,m.start(),m.end())))
        if res: out[os.path.relpath(p,root)]=[len(d),res]
json.dump(out,open("/home/claude/x/hits.json","w"))
open("/home/claude/x/done","w").write(f"{n} files, {len(out)} with hits")
