import struct, sys
W={}
def setw(r,w):
    for o in r: W[o]=w
setw([0x00,0x01,0x04,0x07,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,0x10,0x11,0x12,0x1d,0x1e,0x21,0x27,0x28],1)
setw([0x02,0x05,0x08,0x13,0x15,0x16,0x19,0x1a,0x1c,0x1f,0x20,0x22,0x23,0x29],2)
setw([0x03,0x06,0x09,0x14,0x17,0x1b,0x24,0x25,0x26,0x2a,0x2b,0x2c],3)
W[0x18]=5
setw(range(0x2d,0x32),2); setw(range(0x32,0x3e),2); setw(range(0x3e,0x44),1)
setw(range(0x44,0x52),2); setw(range(0x52,0x60),2); setw(range(0x60,0x6e),2)
setw(range(0x6e,0x73),3); W[0x73]=1; setw(range(0x74,0x79),3); setw([0x79,0x7a],1)
setw(range(0x7b,0x90),1); setw(range(0x90,0xb0),2); setw(range(0xb0,0xd0),1)
setw(range(0xd0,0xe3),2); setw(range(0xe3,0xfa),1); W[0xfa]=4; W[0xfb]=4; W[0xfc]=3; W[0xfd]=3; W[0xfe]=2; W[0xff]=2
def uleb(d,o):
    r=0;s=0
    while True:
        b=d[o];o+=1;r|=(b&0x7f)<<s;s+=7
        if not b&0x80: return r,o
class Dex:
    def __init__(s,path):
        s.d=d=open(path,"rb").read()
        (s.ssz,s.sof)=struct.unpack("<II",d[0x38:0x40])
        s.tsz,s.tof=struct.unpack("<II",d[0x40:0x48])
        s.psz,s.pof=struct.unpack("<II",d[0x48:0x50])
        s.fsz,s.fof=struct.unpack("<II",d[0x50:0x58])
        s.msz,s.mof=struct.unpack("<II",d[0x58:0x60])
        s.csz,s.cof=struct.unpack("<II",d[0x60:0x68])
        s._str={}
    def string(s,i):
        if i in s._str: return s._str[i]
        off=struct.unpack("<I",s.d[s.sof+4*i:s.sof+4*i+4])[0]
        n,o=uleb(s.d,off); e=s.d.index(b"\0",o)
        v=s.d[o:e].decode("utf8","replace"); s._str[i]=v; return v
    def type(s,i): return s.string(struct.unpack("<I",s.d[s.tof+4*i:s.tof+4*i+4])[0])
    def proto(s,i):
        sh,rt,pa=struct.unpack("<III",s.d[s.pof+12*i:s.pof+12*i+12])
        params=[]
        if pa:
            n=struct.unpack("<I",s.d[pa:pa+4])[0]
            params=[s.type(struct.unpack("<H",s.d[pa+4+2*k:pa+6+2*k])[0]) for k in range(n)]
        return "("+"".join(params)+")"+s.type(rt)
    def method(s,i):
        c,p,n=struct.unpack("<HHI",s.d[s.mof+8*i:s.mof+8*i+8])
        return f"{s.type(c)}->{s.string(n)}{s.proto(p)}"
    def field(s,i):
        c,t,n=struct.unpack("<HHI",s.d[s.fof+8*i:s.fof+8*i+8])
        return f"{s.type(c)}->{s.string(n)}:{s.type(t)}"
    def classes(s):
        for i in range(s.csz):
            o=s.cof+32*i
            ci,af,sup,ifs,sf,ann,cd,sv=struct.unpack("<IIIIIIII",s.d[o:o+32])
            yield s.type(ci),af,(s.type(sup) if sup!=0xffffffff else None),cd
    def class_methods(s,cd):
        if not cd: return
        d=s.d
        sfs,o=uleb(d,cd); ifs,o=uleb(d,o); dm,o=uleb(d,o); vm,o=uleb(d,o)
        for _ in range(sfs+ifs):
            _,o=uleb(d,o); _,o=uleb(d,o)
        mi=0
        for cnt,kind in ((dm,"direct"),(vm,"virtual")):
            mi=0
            for _ in range(cnt):
                dlt,o=uleb(d,o); mi+=dlt
                af,o=uleb(d,o); code,o=uleb(d,o)
                yield mi,af,code,kind
    def insns(s,code):
        d=s.d
        rs,ins,outs,tries,dbg,isz=struct.unpack("<HHHHII",d[code:code+16])
        units=struct.unpack("<%dH"%isz,d[code+16:code+16+2*isz])
        pc=0
        while pc<isz:
            u=units[pc]; op=u&0xff
            if op==0 and u!=0:
                if u==0x100: n=units[pc+1]*2+4
                elif u==0x200: n=units[pc+1]*4+2
                else:
                    wd=units[pc+1]; sz=units[pc+2]|(units[pc+3]<<16); n=(sz*wd+1)//2+4
                pc+=n; continue
            w=W.get(op,1)
            yield pc,op,units[pc:pc+w]
            pc+=w
    def trace(s,code):
        out=[]
        for pc,op,u in s.insns(code):
            if op==0x1a: out.append(("str",s.string(u[1])))
            elif op==0x1b: out.append(("str",s.string(u[1]|(u[2]<<16))))
            elif op in (0x6e,0x6f,0x70,0x71,0x72,0x74,0x75,0x76,0x77,0x78): out.append(("call",s.method(u[1])))
            elif op==0x22: out.append(("new",s.type(u[1])))
            elif op==0x1c: out.append(("cls",s.type(u[1])))
            elif 0x52<=op<=0x6d: out.append(("fld",s.field(u[1])))
        return out
if __name__=="__main__":
    path=sys.argv[1]; filt=sys.argv[2:] 
    dx=Dex(path)
    for cname,af,sup,cd in dx.classes():
        if filt and not any(f in cname for f in filt): continue
        print(f"\nCLASS {cname}  extends {sup}  flags=0x{af:x}")
        for mi,maf,code,kind in dx.class_methods(cd):
            print(f"  METHOD {dx.method(mi)}  flags=0x{maf:x} {'(native)' if maf&0x100 else ''}")
            if code:
                for k,v in dx.trace(code):
                    if k in ("str","call","new","cls") :
                        print(f"      {k:4} {v}")
