import ctypes, os, sys
lib = ctypes.CDLL("libarchive.so.13")
lib.archive_read_new.restype = ctypes.c_void_p
lib.archive_entry_pathname.restype = ctypes.c_char_p
lib.archive_entry_size.restype = ctypes.c_int64
for f in ("archive_read_support_format_all","archive_read_support_filter_all"):
    getattr(lib,f).argtypes=[ctypes.c_void_p]
lib.archive_read_open_filename.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t]
lib.archive_read_next_header.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)]
lib.archive_entry_pathname.argtypes=[ctypes.c_void_p]
lib.archive_entry_size.argtypes=[ctypes.c_void_p]
lib.archive_read_data.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t]
lib.archive_error_string.argtypes=[ctypes.c_void_p]; lib.archive_error_string.restype=ctypes.c_char_p
a = lib.archive_read_new()
lib.archive_read_support_format_all(a); lib.archive_read_support_filter_all(a)
src = sys.argv[1]
r = lib.archive_read_open_filename(a, src.encode(), 1<<20)
print("open", r, lib.archive_error_string(a))
e = ctypes.c_void_p()
buf = ctypes.create_string_buffer(1<<20)
while lib.archive_read_next_header(a, ctypes.byref(e)) == 0:
    name = lib.archive_entry_pathname(e).decode(errors="replace")
    size = lib.archive_entry_size(e)
    print("entry:", name, size, flush=True)
    out = os.path.join("/home/claude/x/out", name)
    if name.endswith("/"):
        os.makedirs(out, exist_ok=True); continue
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "wb") as fh:
        while True:
            n = lib.archive_read_data(a, buf, len(buf))
            if n <= 0:
                if n < 0: print("read err", lib.archive_error_string(a))
                break
            fh.write(buf.raw[:n])
