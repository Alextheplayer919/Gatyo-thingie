Files extracted unmodified from Gatyo-1.21.111-Iris-build118.apk (paths mirror the APK).
Verify against evidence/01_hashes.txt.

  lib/arm64-v8a/libReverseSigma.so   main native payload (L10)
  assets/icu/demo.dat                byte-identical fallback copy of the above (L11)
  classes5.dex                       KillerApplication, Patches, amogus.* (L2-L4)
  classes6.dex                       Bootstrap, Platform1, Platform2, GlassBackdrop (L6-L9)
  classes2.dex                       contains MainActivity (calls Patches.patch) (L5)
  AndroidManifest.xml                binary XML (L1)
  META-INF/                          signing files (L12)

Not included: lib/arm64-v8a/libminecraftpe.so (stock game binary, 280 MB, no payload
references) and the other stock libs (libfmod, libmaesdk, etc.).
