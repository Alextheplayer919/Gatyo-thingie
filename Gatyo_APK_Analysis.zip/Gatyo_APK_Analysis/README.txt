Gatyo APK analysis package
==========================
Start with:  REPORT_Gatyo_APK_Analysis.txt
  Section 3 = every location that contains "Gatyo"/"Gato" and what it is responsible for
  Section 4 = payload / loader trace (manifest -> provider -> overlay -> native library)
  Section 6 = telemetry trace (what is proven vs. unknown)
Raw evidence is in evidence/, helper scripts in tools/.
Static analysis only. extracted/ holds the payload binaries and injected dex files; the full APK is not included (hashes only).
